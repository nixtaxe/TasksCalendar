package zabortceva.taskscalendar.localdata;

import java.sql.Timestamp;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverters;

@Entity(tableName = "task_table")
public class Task {

    @PrimaryKey(autoGenerate = true)
    private int id;

    //Название задачи
    private String name;

    //Описание задачи
    private String details;

    private char status = 'q';

    private int event_id;

    private int parent_id;

    @TypeConverters({Converters.class})
    private Timestamp deadline_at;

    @TypeConverters({Converters.class})
    private Timestamp created_at;

    @TypeConverters({Converters.class})
    private Timestamp updated_at;

    public Task(String name, String details, Timestamp deadline_at) {
        this.name = name;
        this.details = details;
        this.deadline_at = deadline_at;
        this.created_at = new Timestamp(System.currentTimeMillis());
    }

//    public Task() {
//        this.name = "Default";
//        this.details = "Default";
//        this.deadline_at = new Timestamp(System.currentTimeMillis());
//        this.created_at = new Timestamp(System.currentTimeMillis());
//    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", details='" + details + '\'' +
                ", deadline_at=" + deadline_at.toString() +
                ", created_at=" + created_at.toString() +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDetails() {
        return details;
    }

    public char getStatus() {
        return status;
    }

    public int getEvent_id() {
        return event_id;
    }

    public int getParent_id() {
        return parent_id;
    }

    public Timestamp getDeadline_at() {
        return deadline_at;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public Timestamp getUpdated_at() {
        return updated_at;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public void setEvent_id(int event_id) {
        this.event_id = event_id;
    }

    public void setParent_id(int parent_id) {
        this.parent_id = parent_id;
    }

    public void setDeadline_at(Timestamp deadline_at) {
        this.deadline_at = deadline_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public void setUpdated_at(Timestamp updated_at) {
        this.updated_at = updated_at;
    }
}
