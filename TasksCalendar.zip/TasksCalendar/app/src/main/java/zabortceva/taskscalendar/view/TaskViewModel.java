package zabortceva.taskscalendar.view;

import android.app.Application;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import zabortceva.taskscalendar.localdata.Task;
import zabortceva.taskscalendar.repository.CalendarRepository;

public class TaskViewModel extends AndroidViewModel {
    private CalendarRepository repository;
    private LiveData<List<Task>> dayTasks;

    public TaskViewModel(Application application) {
        super(application);
        repository = new CalendarRepository(application);
//        dayTasks = repository.getDayTasks(new Timestamp(System.currentTimeMillis()));
        dayTasks = repository.getAllTasks();
    }

    public void insert(Task task) {
        repository.insert(task);
    }

    public void update(Task task) {
        repository.update(task);
    }

    public void delete(Task task) {
        repository.delete(task);
    }

    public LiveData<List<Task>> getDayTasks(Timestamp timestamp) {
        return repository.getDayTasks(timestamp);
    }

    public LiveData<List<Task>> getAllTasks() {
        return repository.getAllTasks();
    }
}
