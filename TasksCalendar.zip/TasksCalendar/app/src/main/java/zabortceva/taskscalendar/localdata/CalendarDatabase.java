package zabortceva.taskscalendar.localdata;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.TypeConverter;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import android.os.AsyncTask;

import java.sql.Timestamp;
import java.util.Date;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.support.annotation.NonNull;

@Database(entities = {Task.class, Event.class, EventPattern.class, User.class},
version = 1)
@TypeConverters({Converters.class})
public abstract class CalendarDatabase extends RoomDatabase {

    private static CalendarDatabase instance;

    public abstract TaskDao taskDao();

    public static synchronized CalendarDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    CalendarDatabase.class, "calendar_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private TaskDao taskDao;

        private PopulateDbAsyncTask(CalendarDatabase db) {
            taskDao = db.taskDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            taskDao.insert(new Task("Title 1", "Description 1", new Timestamp(System.currentTimeMillis())));
            taskDao.insert(new Task("Title 2", "Description 2", new Timestamp(System.currentTimeMillis())));
            return null;
        }
    }
}
