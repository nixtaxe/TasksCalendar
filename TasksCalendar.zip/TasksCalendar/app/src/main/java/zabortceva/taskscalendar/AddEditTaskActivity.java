package zabortceva.taskscalendar;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Calendar;

public class AddEditTaskActivity extends AppCompatActivity {

    public static final String EXTRA_TASK_ID = "zabortceva.taskscalendar.EXTRA_TASK_ID";
    public static final String EXTRA_TASK_NAME = "zabortceva.taskscalendar.EXTRA_TASK_NAME";
    public static final String EXTRA_TASK_DETAILS = "zabortceva.taskscalendar.EXTRA_TASK_DETAILS";
    public static final String EXTRA_TASK_DEADLINE_AT = "zabortceva.taskscalendar.EXTRA_TASK_DEADLINE_AT";

    private final String TAG = "AddEditTaskActivity";

    private EditText editTaskName;
    private EditText editTaskDetails;
    private EditText editDeadlineAt;
    private TextView selectedDate;
    private EditText selectDateTimeButton;
    private FloatingActionButton saveTaskButton;
    private DatePickerDialog.OnDateSetListener dateSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        selectedDate = findViewById(R.id.selected_date);
        selectedDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.YEAR);
                int day = calendar.get(Calendar.YEAR);

                DatePickerDialog dialog = new DatePickerDialog(AddEditTaskActivity.this,
                        android.R.style.Theme_DeviceDefault_Light, dateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        editTaskName = findViewById(R.id.edit_task_name);
        editTaskDetails = findViewById(R.id.edit_task_details);
        editDeadlineAt = findViewById(R.id.edit_deadline_at);

        saveTaskButton = findViewById(R.id.save_task_button);
        saveTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
//                String date =
            }
        };

        Intent intent = getIntent();

        if (intent.hasExtra(EXTRA_TASK_ID)) {
            editTaskName.setText(intent.getStringExtra(EXTRA_TASK_NAME));
            editTaskDetails.setText(intent.getStringExtra(EXTRA_TASK_DETAILS));
            editDeadlineAt.setText(intent.getStringExtra(EXTRA_TASK_DEADLINE_AT));
        }
    }

    private void saveTask() {
        String name = editTaskName.getText().toString();
        String details = editTaskDetails.getText().toString();
        String deadline_at = editDeadlineAt.getText().toString();

        if (name.trim().isEmpty() && details.trim().isEmpty()) {
            Toast.makeText(this, "Please insert title of description.", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            Timestamp timestamp = Timestamp.valueOf(deadline_at);
        } catch (Exception e) {
            Toast.makeText(this, "Invalid date", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent data = new Intent();
        data.putExtra(EXTRA_TASK_NAME, name);
        data.putExtra(EXTRA_TASK_DETAILS, details);
        data.putExtra(EXTRA_TASK_DEADLINE_AT, deadline_at);

        int id = getIntent().getIntExtra(EXTRA_TASK_ID, -1);
        if (id != -1) {
            data.putExtra(EXTRA_TASK_ID, id);
        }

        setResult(RESULT_OK, data);
        finish();
    }
}
