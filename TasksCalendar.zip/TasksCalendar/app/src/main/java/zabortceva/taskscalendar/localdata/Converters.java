package zabortceva.taskscalendar.localdata;

import android.arch.persistence.room.TypeConverter;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.provider.SyncStateContract;

import java.sql.Timestamp;
import java.text.ParseException;

public class Converters {

    @TypeConverter
    public static Timestamp fromLong(Long value) {
        return value == null ? null : new Timestamp(value);
    }

    @TypeConverter
    public static Long timestampToLong(Timestamp timestamp) {
        return timestamp == null ? null : timestamp.getTime();
    }
//    @TypeConverter
//    public static Timestamp fromString(String value) {
//        return value == null ? null : Timestamp.valueOf(value);
//    }
//
//    @TypeConverter
//    public static String timestampToString(Timestamp timestamp) {
//        return timestamp == null ? null : timestamp.toString();
//    }
}
