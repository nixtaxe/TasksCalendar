package zabortceva.taskscalendar.repository;

import android.app.Application;
import android.os.AsyncTask;

import java.sql.Timestamp;
import java.util.List;

import android.arch.lifecycle.LiveData;
import zabortceva.taskscalendar.localdata.CalendarDatabase;
import zabortceva.taskscalendar.localdata.Task;
import zabortceva.taskscalendar.localdata.TaskDao;

public class CalendarRepository {
    //TODO make interface Repository
    //TODO implement Room repository
    //TODO implement offline web repository
    //TODO implement online web repository

    private TaskDao taskDao;
    private LiveData<List<Task>> dayTasks;

    public CalendarRepository(Application application) {
        CalendarDatabase localDatabase = CalendarDatabase.getInstance(application);
        taskDao = localDatabase.taskDao();
        dayTasks = taskDao.getAllTasks();
//        dayTasks = taskDao.getDayTasks(new Timestamp(System.currentTimeMillis()));
    }

    public void insert(Task task) {
        new InsertTaskAsyncTask(taskDao).execute(task);
    }

    public void update(Task task) {
        new UpdateTaskAsyncTask(taskDao).execute(task);
    }

    public void delete(Task task) {
        new DeleteTaskAsyncTask(taskDao).execute(task);
    }

    public LiveData<List<Task>> getDayTasks(Timestamp day) {
        dayTasks = taskDao.getDayTasks(day.getTime());
        return dayTasks;
    }

    public LiveData<List<Task>> getAllTasks() {
        dayTasks = taskDao.getAllTasks();
        return dayTasks;
    }

    private static class InsertTaskAsyncTask extends AsyncTask<Task, Void, Void> {
        private TaskDao taskDao;

        private InsertTaskAsyncTask(TaskDao taskDao) {
            this.taskDao = taskDao;
        }

        @Override
        protected Void doInBackground(Task... tasks) {
            taskDao.insert(tasks[0]);
            return null;
        }
    }

    private static class UpdateTaskAsyncTask extends AsyncTask<Task, Void, Void> {
        private TaskDao taskDao;

        private UpdateTaskAsyncTask(TaskDao taskDao) {
            this.taskDao = taskDao;
        }

        @Override
        protected Void doInBackground(Task... tasks) {
            taskDao.update(tasks[0]);
            return null;
        }
    }

    private static class DeleteTaskAsyncTask extends AsyncTask<Task, Void, Void> {
        private TaskDao taskDao;

        private DeleteTaskAsyncTask(TaskDao taskDao) {
            this.taskDao = taskDao;
        }

        @Override
        protected Void doInBackground(Task... tasks) {
            taskDao.delete(tasks[0]);
            return null;
        }
    }
 }
