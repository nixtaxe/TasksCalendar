package zabortceva.taskscalendar;

import android.arch.lifecycle.Observer;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import android.arch.lifecycle.ViewModelProviders;
import android.widget.Toast;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.spans.DotSpan;

import zabortceva.taskscalendar.localdata.Task;
import zabortceva.taskscalendar.view.TaskViewModel;
import zabortceva.taskscalendar.view.TasksAdapter;

public class CalendarActivity extends AppCompatActivity {

    public static final int ADD_NOTE_REQUEST = 1;
    public static final int EDIT_NOTE_REQUEST = 2;
    private static final String TAG = "CalendarActivity";

    //TODO adjust insertion into table
    //TODO add deletion from table
    //TODO add update of table

    //TODO figure out how to implement events and users

    private MaterialCalendarView calendarView;
    private RecyclerView tasksView;
    private FloatingActionButton addTaskButton;
    final TasksAdapter tasksAdapter = new TasksAdapter();

    private TaskViewModel taskViewModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);

        tasksView = findViewById(R.id.tasksView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        tasksView.setLayoutManager(layoutManager);
        tasksView.setAdapter(tasksAdapter);

        taskViewModel = ViewModelProviders.of(this).get(TaskViewModel.class);
        observeNewDay(new Timestamp(System.currentTimeMillis()));
        taskViewModel.getAllTasks().observe(this, new Observer<List<Task>>() {
            @Override
            public void onChanged(@Nullable List<Task> tasks) {
//                tasksAdapter.setTasks(tasks);
                if (tasks == null)
                    return;
                List<CalendarDay> days = new ArrayList<>();
                for (Task task : tasks) {
                    days.add(CalendarDay.from(task.getDeadline_at()));
                }
                calendarView.addDecorator(new EventDecorator(0, days));
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                taskViewModel.delete(tasksAdapter.getTaskAt(viewHolder.getAdapterPosition()));
                Toast.makeText(CalendarActivity.this, "Task deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(tasksView);

        tasksAdapter.setOnItemClickListener(new TasksAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Task task) {
                Intent intent = new Intent(CalendarActivity.this, AddEditTaskActivity.class);

                intent.putExtra(AddEditTaskActivity.EXTRA_TASK_ID, task.getId());
                intent.putExtra(AddEditTaskActivity.EXTRA_TASK_NAME, task.getName());
                intent.putExtra(AddEditTaskActivity.EXTRA_TASK_DETAILS, task.getDetails());
                intent.putExtra(AddEditTaskActivity.EXTRA_TASK_DEADLINE_AT, task.getDeadline_at().toString());
                startActivityForResult(intent, EDIT_NOTE_REQUEST);
            }
        });

        calendarView = findViewById(R.id.calendarView);
        calendarView.setTileHeightDp(40);
        calendarView.setTileWidthDp(60);
        calendarView.setShowOtherDates(MaterialCalendarView.SHOW_DEFAULTS);
        calendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView materialCalendarView, @NonNull CalendarDay calendarDay, boolean b) {
                //Mind the localtime in sql query
                observeNewDay(new Timestamp(calendarDay.getDate().getTime()));
            }
        });
        calendarView.setSelectedDate(new Date(System.currentTimeMillis()));

        addTaskButton = findViewById(R.id.add_task_button);
        addTaskButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CalendarActivity.this, AddEditTaskActivity.class);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });
    }

    private void observeNewDay(Timestamp timestamp) {
        taskViewModel.getDayTasks(timestamp).observe(this, new Observer<List<Task>>() {
            @Override
            public void onChanged(@Nullable List<Task> tasks) {
                tasksAdapter.submitList(tasks);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK) {
            String name = data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_NAME);
            String details = data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_DETAILS);
            Timestamp deadline_at = Timestamp.valueOf(data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_DEADLINE_AT));

            Task task = new Task(name, details, deadline_at);
            taskViewModel.insert(task);

            Toast.makeText(this, "Task saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(AddEditTaskActivity.EXTRA_TASK_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Note can't ba updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String name = data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_NAME);
            String details = data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_DETAILS);
            Timestamp deadline_at = Timestamp.valueOf(data.getStringExtra(AddEditTaskActivity.EXTRA_TASK_DEADLINE_AT));

            Task task = new Task(name, details, deadline_at);
            task.setId(id);
            taskViewModel.update(task);

            Toast.makeText(this, "Task updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Task not saved", Toast.LENGTH_SHORT).show();
        }
    }

    public class EventDecorator implements DayViewDecorator {

        private final int color;
        private final HashSet<CalendarDay> dates;

        public EventDecorator(int color, Collection<CalendarDay> dates) {
            this.color = color;
            this.dates = new HashSet<>(dates);
        }

        @Override
        public boolean shouldDecorate(CalendarDay day) {
            return dates.contains(day);
        }

        @Override
        public void decorate(DayViewFacade view) {
            view.addSpan(new DotSpan(5, color));
        }
    }
}
