package zabortceva.taskscalendar.localdata;

import java.sql.Timestamp;
import java.util.List;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import android.support.annotation.Nullable;

@Dao
public interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    Long insert(Task task);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void update(Task task);

    @Delete
    void delete(Task task);

    @Query("DELETE FROM task_table WHERE id = :id")
    void deleteDuplicates(int id);

    @Query("SELECT * FROM task_table WHERE date(deadline_at) = date(:day) ORDER BY deadline_at ASC")
    LiveData<List<Task>> getDayTasks(String day);

    @Query("SELECT * FROM task_table WHERE strftime('%d-%m-%Y', deadline_at / 1000, 'unixepoch', 'localtime') " +
            " = strftime('%d-%m-%Y', :day / 1000, 'unixepoch', 'localtime') ORDER BY deadline_at ASC")
    LiveData<List<Task>> getDayTasks(Long day);

    @Query("SELECT * FROM task_table")
    LiveData<List<Task>> getAllTasks();
}
