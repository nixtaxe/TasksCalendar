package zabortceva.taskscalendar.view;

import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.RecoverySystem;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import zabortceva.taskscalendar.CalendarActivity;
import zabortceva.taskscalendar.R;
import zabortceva.taskscalendar.localdata.Task;

public class TasksAdapter extends ListAdapter<Task, TasksAdapter.TaskViewHolder> {
    private OnItemClickListener listener;

    public TasksAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Task> DIFF_CALLBACK = new DiffUtil.ItemCallback<Task>() {
        @Override
        public boolean areItemsTheSame(@NonNull Task task, @NonNull Task t1) {
            return task.getId() == t1.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Task task, @NonNull Task t1) {
            return task.getName().equals(t1.getName()) &&
                    task.getDetails().equals(t1.getDetails()) &&
                    task.getDeadline_at() == t1.getDeadline_at() &&
                    task.getCreated_at() == t1.getCreated_at();
        }
    };

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.task_item, viewGroup, false);
        return new TaskViewHolder(itemView);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder taskViewHolder, int i) {
        Task currentTask = getItem(i);
        taskViewHolder.listItemTimeView.setText(new SimpleDateFormat("HH:mm").format(currentTask.getDeadline_at()));
        taskViewHolder.listItemNameView.setText(currentTask.getName());
        taskViewHolder.listItemTaskContentView.setText(currentTask.getDetails());
    }

    class TaskViewHolder extends RecyclerView.ViewHolder {

        TextView listItemTimeView;
        TextView listItemNameView;
        TextView listItemTaskContentView;

        public TaskViewHolder(View itemView) {
            super(itemView);

            listItemTimeView = itemView.findViewById(R.id.task_time);
            listItemNameView = itemView.findViewById(R.id.task_name);
            listItemTaskContentView = itemView.findViewById(R.id.task_content);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        void bind(int listIndex) {
            Task currentTask = getItem(listIndex);
            listItemTimeView.setText(new SimpleDateFormat("HH:mm").format(currentTask.getDeadline_at()));
            listItemNameView.setText(currentTask.getName());
            listItemTaskContentView.setText(currentTask.getDetails());
        }
    }

    public Task getTaskAt(int position) {
        return getItem(position);
    }

    public interface OnItemClickListener {
        void onItemClick(Task task);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
